"""
Example Multi-Agent Systems for demonstration and testing.
"""

from mas_eval.examples.research_mas import ResearchMAS, create_research_mas

__all__ = ["ResearchMAS", "create_research_mas"]
